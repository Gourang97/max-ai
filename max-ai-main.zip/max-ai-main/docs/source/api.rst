API
===

.. autosummary::
   :toctree: generated

   max
