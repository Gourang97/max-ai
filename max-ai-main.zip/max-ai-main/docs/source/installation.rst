Installation Guide
=====

.. _installation:


To use maxai, first install it using pip:

.. code-block:: console

   (.venv) $ pip install maxai-1.0.0-py3-none-any.whl


